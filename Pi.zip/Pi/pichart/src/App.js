import React from 'react';
import './App.css';
import GraphChart from './GraphChart'
 
function App() {
  return (
    <div className="App">
          <GraphChart/>
    </div>
  );
}
 
export default App;